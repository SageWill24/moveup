<?php
if (is_dir("imgs/")) {
    $dircheckPath = "";
}elseif (is_dir("../imgs/")) {
    $dircheckPath = "../";
}elseif (is_dir("<?php echo $dircheckPath; ?>imgs/")) {
    $dircheckPath = "<?php echo $dircheckPath; ?>";
}
// ================================ check user exist ===================================
session_start();
$mys = $_SESSION['Username'];
$uCheckSession_sql = "SELECT Username FROM signup WHERE Username=:mys";
$uCheckSession = $conn->prepare($uCheckSession_sql);
$uCheckSession->bindParam(':mys',$mys,PDO::PARAM_STR);
$uCheckSession->execute();
$uCheckSessionCount = $uCheckSession->rowCount();
if ($uCheckSessionCount == 0) {
    session_unset();
    session_destroy();
}
?>

<nav class="w3-sidebar  w3-bar-block w3-card" id="mySidebar">
<div class="w3-container w3-theme-d2">
  <br>
   <?php
       if (is_file("home.php")) {
                  $homePath = "home";
                }elseif (is_file("../home.php")) {
                    $homePath = "../home";
                }elseif (is_file("../../home.php")) {
                    $homePath = "../../home";
                }
                ?>
  <span onclick="closeSidebar()" class="w3-button w3-display-topright w3-xxlarge">X</span>
  <br><br>
  <div class="w3-padding ">
    <img class="w3-circle"  alt="avatar" style="width:30%"  src="<?php echo $dircheckPath.'imgs/user_imgs/'.$_SESSION['Userphoto']; ?>">
    <p class="w3-text-black"><a href="<?php echo $dircheckPath; ?>u/<?php echo $_SESSION['Username']; ?>"><?php echo $_SESSION['Fullname']."<br><span style='color: #848484; font-size: 13px;'>@".$_SESSION['Username']."</span>"; ?>  </a></p>
  </div>

<a class="w3-bar-item w3-button w3-text-black" href="<?php echo $dircheckPath; ?>u/<?php echo $_SESSION['Username']; ?>">profile</a>
<a class="w3-bar-item w3-button w3-text-black" href="<?php echo $dircheckPath; ?>settings">Settings</a>
<a class="w3-bar-item w3-button w3-text-black" href="<?php echo $dircheckPath; ?>logout">LogOut</a>
</nav>

<header class="w3-top w3-bar w3-white">
  <button class="w3-bar-item w3-button w3-text-blue w3-xlarge w3-hover-theme" onclick="openSidebar()">&#9776;</button>
<p class="w3-text-blue w3-bar-item"><b>Trappisone</b></p>
<a href="<?php echo $dircheckPath; ?>notifications"><i class="material-icons w3-hide-small w3-text-blue">group</i></a>
 <a href="<?php echo $dircheckPath; ?>post"><i class="material-icons w3-hide-small w3-text-blue ">create</i></a>
<a href="javascript:void(0);"class="w3-right w3-text-blue w3-padding-4 w3-icon" style="padding: 10px 5px;" id="nav_Noti_Btn"><i class="material-icons ">notifications_none</i> <?php echo lang('Notifications'); ?><small> <span id="notificationsCount"></span></small></a>
</header>
                <div class="w3-container">
                <div class=" w3-card w3-white navbar_fetchBox " id="notifications_box">
                <div style="position:relative;"><small><?php echo lang('notifications'); ?></small>
                    <span class="toTopArrow" span class='toTopArrow' style="position: absolute; top: -10px;<?php echo lang('float'); ?>:30px;"></span>
                </div>
                <div id="notifications_rP" class="scrollbar" style=" overflow-y: scroll;">
                    <div id="notifications_r" data-load="0">
                        <div id="notifications_data"></div>
                        <p style='width: 20%;border:none;display: none' id="notifications_loading" align='center'><img src='<?php echo $dircheckPath; ?>imgs/loading_video.gif' style='width:20px;box-shadow: none;height: 20px;'></p>
                        <p id="notifications_noMore" style='display:none;color:#9a9a9a;font-size:14px;text-align:center;'><?php echo lang('no_notifications'); ?></p>
                        <input type="hidden" id="notifications_load" value="0"> 
                    </div>
                </div>
                <div id='sqresultItem' align='center' style='background: #efefef; border: 1px solid #e0e0e0;'>
                <a href='<?php echo $dircheckPath; ?>notifications'>
               <div style='display: inline-flex;width: 100%;'>
                <p style='font-size:13px;'><?php echo lang('see_all'); ?>
                </p>
                </div>
                </a>
                </div>
                </div>
                <div id="nav_newNotify" data-show='0'></div>
</div>
<div style="" id='nSound'></div>
<?php include ($dircheckPath."js/navbar_nottifi_js.php"); ?>
<script>
closeSidebar();
function openSidebar() {
  document.getElementById("mySidebar").style.display = "block";
}

function closeSidebar() {
  document.getElementById("mySidebar").style.display = "none";
}
</script>