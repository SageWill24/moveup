<?php
if (is_dir("imgs/")) {
    $dircheckPath = "";
}elseif (is_dir("../imgs/")) {
    $dircheckPath = "../";
}elseif (is_dir("<?php echo $dircheckPath; ?>imgs/")) {
    $dircheckPath = "<?php echo $dircheckPath; ?>";
}
// ================================ check user exist ===================================
session_start();
$mys = $_SESSION['Username'];
$uCheckSession_sql = "SELECT Username FROM signup WHERE Username=:mys";
$uCheckSession = $conn->prepare($uCheckSession_sql);
$uCheckSession->bindParam(':mys',$mys,PDO::PARAM_STR);
$uCheckSession->execute();
$uCheckSessionCount = $uCheckSession->rowCount();
if ($uCheckSessionCount == 0) {
    session_unset();
    session_destroy();
}
?>
<link href="<?php echo $dircheckPath; ?>dist/css/lib/bootstrap.min.css" type="text/css" rel="stylesheet">
<link rel="stylesheet" href="<?php echo $dircheckPath; ?>dist/css/w3.css">
<link href="<?php echo $dircheckPath; ?>css/design.css" rel="stylesheet">

        <!-- Swipe core CSS -->
<link href="<?php echo $dircheckPath; ?>dist/css/swipe.min.css" type="text/css" rel="stylesheet">

<div class="navigation w3-light w3-round">
          <div class="container">
            <div class="inside w3-hide-large">
              <div class="nav nav-tab menu w3-text-blue">
              
                <a href="<?php echo $homePath; ?>"><i class="fa fa-coronavirus fa-fw"></i><center>Covid19 South Africa</a>
               
                
              </div>
            </div>
          </div>
        </div> 