<?php
error_reporting(E_ALL ^ E_NOTICE);
session_start();
$myId = $_SESSION['id'];
include("../config/connect.php");
include("../includes/fetch_users_info.php");
include("../includes/time_function.php");
include("../includes/country_name_function.php");
include("../includes/num_k_m_count.php");
if(!isset($_SESSION['Username'])){
    header("location: ../index");
}

$_SESSION['user_photo'] = $row_author_photo;
if (is_dir("imgs/")) {
        $check_path = "";
    }elseif (is_dir("../imgs/")) {
        $check_path = "../";
    }elseif (is_dir("../../imgs/")) {
        $check_path = "../../";

    }
?>
<html dir="<?php echo lang('html_dir'); ?>">
<head>
    <title><?php echo $row_username; ?> | Wallstant</title>
    <meta charset="UTF-8">
    <meta name="description" content="<?php echo $row_bio; ?>">
    <meta name="keywords" content="social network,social media,Wallstant,meet,free platform">
    <meta name="author" content="Munaf Aqeel Mahdi">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="<?php echo $dircheckPath; ?>dist/css/lib/bootstrap.min.css" type="text/css" rel="stylesheet">
<link rel="stylesheet" href="<?php echo $dircheckPath; ?>dist/css/w3.css">

        <!-- Swipe core CSS -->
<link href="<?php echo $dircheckPath; ?>dist/css/swipe.min.css" type="text/css" rel="stylesheet">
        <!-- Favicon -->
<link href="<?php echo $dircheckPath; ?>dist/img/favicon.png" type="image/png" rel="icon">
 <link rel="stylesheet" href="<?php echo $dircheckPath; ?>vendor/bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome CSS-->
    
    <!-- Google fonts - Popppins for copy-->
  
    <link rel="stylesheet" href="<?php echo $dircheckPath; ?>css/orionicons.css">
    <!-- theme stylesheet-->
    <link rel="stylesheet" href="<?php echo $dircheckPath; ?>css/style.default.css" id="theme-stylesheet">
    <!-- Custom stylesheet - for your changes-->
    <link rel="stylesheet" href="<?php echo $dircheckPath; ?>css/custom.css">
    <!-- Favicon-->
    <link rel="shortcut icon" href="<?php echo $dircheckPath; ?>img/favicon.png?3">
    <?php include "../includes/head_imports_main.php";?>
    </script>
    <style type="text/css">
body{
    background:#000;
    
}
 .user_info{
        text-align:<?php echo lang('user_info_align');?>;
        }
        .comment_field{
        text-align:<?php echo lang('comment_field_align');?>;
        }
       hr.head {
    height: 12px;
    border: 0;
    box-shadow: inset 0 12px 12px -12px rgba(0, 0, 0, 0.5);
}
    </style>
</head>
    <body onload="fetchPosts_DB('user')">
<header class="w3-top w3-bar w3-white">
                  <?php
                if (is_file("home.php")) {
                    $homePath = "home";
                }elseif (is_file("../home.php")) {
                    $homePath = "../home";
                }elseif (is_file("../../home.php")) {
                    $homePath = "../../home";
                }
                ?>
  <button class="w3-bar-item w3-button w3-text-blue w3-xlarge w3-hover-theme"><a href="<?php echo $homePath; ?>"><i class="material-icons">arrow_back</i></a></button>
<p class="w3-text-blue"style="margin-top:10px; padding-left:10px; "><?php echo "<a href='".$row_username."'>$row_username</a>";?></p>
</header>
<?php include "../includes/bottomnav.php"; ?>
<?php
if (filter_var(htmlspecialchars($_GET['u']),FILTER_SANITIZE_STRING) == $row_username) {
?>
<br><br><br><br><br><br><br>
<div class="container">
  <div class="w3-row">
    <!-- Middle Column -->
    <div class="w3-col m7">
    
      <div class="w3-row-padding">
        <div class="w3-col m5">
          <div class="w3-card w3-round w3-white">
            <div class="w3-container w3-padding">

        <div class="user" style="overflow: visible;position: relative;">
            <?
            if ($row_username == $_SESSION['Username']) {
                $userActive = "#4CAF50";
            }else{
                if ($row_online == "1") {
                    $userActive = "#4CAF50";
                }else{
                    $userActive = "#ccc";
                }
            }
            ?>
         
        <?php
         if ($row_profile_pic_border == "1") {
             $profile_pic_border_var = "border-radius: 5%";
         }else{
             $profile_pic_border_var = "";
         }
        ?>
        <div class="profile_picture_img profile_ppicture" style="<?php echo $profile_pic_border_var;?>">
            <img src="<?php echo "../imgs/user_imgs/$row_user_photo";?>" alt="<?php echo $row_username;?>" id="profilePhotoPreview" />
            <?php
            include "../includes/uploadprofilephoto.php";
            if($_SESSION['Username'] == $row_username){
                echo "
                <div class=\"change_user_photo\">

                <form action=\"\" method=\"post\" enctype=\"multipart/form-data\">
                <label style='margin:0;'>
                    <p style='margin:0;color: #fff;text-align: center;'><span class=\"fa fa-camera\"></span> ".lang('uploadPhoto')."</p>
                    <input style=\"display: none;\" type=\"file\" accept=\"image/png, image/jpeg, image/jpeg\" name=\"photo_field\" onchange='profilePhoto(this);' />
                </label>
                <button type=\"submit\" name=\"submit_photo\" id='submitProfilePhoto' style='display:none;' >
                <span class='fa fa-check' style='
                background:rgba(62, 187, 74, 0.88);width: 100%;border-radius: 3px;padding: 2px;color: #fff;'> <span style='font-family: sans-serif;'>".lang('save')."
                <span></span></span></span></button>
                </form>
                </div>
                ";
            }
            ?>
            </div></div>
 
       <?php
            $url = '/(http|https|ftp|ftps)\:\/\/[a-zA-Z0-9\-\.]+\.[a-zA-Z]{2,3}(\:[0-9]+)?(\/\S*)?/';
            $website_row = preg_replace($url, '<a href="$0" target="_blank" title="$0">$0</a>', $row_website);
            ?>
        <div class="profile_picture">
            <h3 style="margin-top:30px; "><?php echo "<a href='".$row_username."'>$row_fullname</a>"; if ($row_verify == "1"){echo $verifyUser;} ?></h3>
            <p align="center">@<?php echo $row_username;?></p>

          </div>
        </div>
            </div>
          </div>
        
 <div class="profile_menu_details" style="display:inline-flex;">
                <?php
          $posts_num_sql = "SELECT post_id FROM wpost WHERE author_id=:row_id";
                $posts_num = $conn->prepare($posts_num_sql);
                $posts_num->bindParam(':row_id',$row_id,PDO::PARAM_INT);
                $posts_num->execute();
                $posts_num_int = $posts_num->rowCount();
                //=====================================================================
                $followers_sql = "SELECT id FROM follow WHERE uf_two=:row_id";
                $followers = $conn->prepare($followers_sql);
                $followers->bindParam(':row_id',$row_id,PDO::PARAM_INT);
                $followers->execute();
                $followers_num = $followers->rowCount();
                //=====================================================================
                $following_sql = "SELECT id FROM follow WHERE uf_one=:row_id";
                $following = $conn->prepare($following_sql);
                $following->bindParam(':row_id',$row_id,PDO::PARAM_INT);
                $following->execute();
                $following_num = $following->rowCount();
                ?>
             
                 <a href='<?php echo $row_username;?>&ut=posts' id='posts_btn' class='profileMenuItem'>
                <b><?php echo thousandsCurrencyFormat($posts_num_int); ?></b> <?php echo lang('posts_str'); ?></a>
                <span id='followersCount' style="display:inline-flex;">
                <a href='<?php echo $row_username;?>&ut=followers' id='followers_btn' class='profileMenuItem'>
                <b><?php echo thousandsCurrencyFormat($followers_num); ?></b> <?php echo lang('followers_str'); ?></a></span>
                <a href='<?php echo $row_username;?>&ut=following' id='following_btn' class='profileMenuItem'>
                <b><?php echo thousandsCurrencyFormat($following_num); ?></b> <?php echo lang('following_str'); ?></a>
            </div><br>
 <div style="display: flex;">
            <?php
               if($row_id != $_SESSION['id']){
                $csql = "SELECT id FROM follow WHERE uf_one=:s_id AND uf_two=:row_id";
                $c = $conn->prepare($csql);
                $c->bindParam(':s_id',$s_id,PDO::PARAM_INT);
                $c->bindParam(':row_id',$row_id,PDO::PARAM_INT);
                $c->execute();
                $c_num = $c->rowCount();
                if ($c_num > 0){
                    echo "<span id='followUnfollow_$row_id' style='cursor:pointer;width:50%;display:inline-flex;'><button class=\"unfollow_btn\" onclick=\"followUnfollow('$row_id')\"><span class=\"fa fa-check\"></span> ".lang('followingBtn_str')."</button></span>";
                }else{
                    echo "<span id='followUnfollow_$row_id' style='cursor:pointer;width:50%;display:inline-flex;'><button class=\"follow_btn\" onclick=\"followUnfollow('$row_id')\"><span class=\"fa fa-plus-circle\"></span> ".lang('followBtn_str')."</button></span>";
                }
  //=====================================================================space for message Bun
                }
                ?>
                </div>
                <?php
                if($row_id == $_SESSION['id']){
                    echo "<span style='cursor:pointer;width:100%;display:inline-flex;'><a href='../settings?tc=edit_profile' class=\"silver_flat_btn\" style='width:100%;'><span class=\"fa fa-cog\"></span> ".lang('edit_profile')."</a></span>";
                }
                ?>
   
      </div>
</center>
<!--===============================================posts_section====================================================-->
<!--===============================================posts_section====================================================-->
<div id="posts_section">
<?php echo $err_success_Msg; ?>
<?php
$s_id = $_SESSION['id'];
$emptyImg = '';
$getphotos_sql = "SELECT * FROM wpost WHERE author_id=:s_id AND post_img != :emptyImg ORDER BY post_time";
$getphotos = $conn->prepare($getphotos_sql);
$getphotos->bindParam(':s_id',$s_id,PDO::PARAM_INT);
$getphotos->bindParam(':emptyImg',$emptyImg,PDO::PARAM_STR);
$getphotos->execute();
$getphotos_num = $getphotos->rowCount();
if ($_SESSION['id'] == $row_id) {
    include("../includes/w_post_form.php");
}
?>
<?php
if ($getphotos_num > 0) {

}
if ($posts_num_int < 1) {
if ($_SESSION['id'] == $row_id) {
echo "
<div class='post'>
<p style='color: gray;text-align: center;padding: 15px;margin: 0px;'>".lang('you_have_not_posted_anything_yet').".</p>
</div>
";
 }else{
echo "
<div class='post'>
<p style='color: gray;text-align: center;padding: 15px;margin: 0px;'>$row_fullname ".lang('has_not_posted_anything_yet').".</p>
</div>
";
 } 
}
?><hr>
<p class="w3-text-black"> Pins below</p>
<!--========================================================================-->
                <div id="FetchingPostsDiv">
                </div>
                <div class="post loading-info" id="LoadingPostsDiv" style="padding: 8px;padding-bottom: 100px;">
                    <div class="animated-background">
                        <div class="background-masker header-top"></div>
                        <div class="background-masker header-left"></div>
                        <div class="background-masker header-right"></div>
                        <div class="background-masker header-bottom"></div>
                        <div class="background-masker subheader-left"></div>
                        <div class="background-masker subheader-right"></div>
                        <div class="background-masker subheader-bottom"></div>
                        <div class="background-masker content-top"></div>
                        <div class="background-masker content-first-end"></div>
                        <div class="background-masker content-second-line"></div>
                        <div class="background-masker content-second-end"></div>
                        <div class="background-masker content-third-line"></div>
                        <div class="background-masker content-third-end"></div>
                    </div>
                </div>
                <div class="post  loading-info" id="NoMorePostsDiv" style="display: none;">
                  <p style="color: #b1b1b1;text-align: center;padding: 15px;margin: 0px;font-size: 18px;"><?php echo lang('noMoreStories'); ?></p>
                </div>
                <div class="post  loading-info" id="LoadMorePostsBtn" style="display: none;">
                  <button class="blue_flat_btn" style="width: 100%" onclick="fetchPosts_DB('user')">Load more</button>
                </div>
                <input type="hidden" id="GetLimitOfPosts" value="0">
</div></div></div></div>
        </div>
<?php
{
?>
<style type="text/css">
body{
background: #fff;
}
.error_page_btn{
background: whitesmoke;
padding: 8px;
border-radius: 3px;
color: #6b6b6b;
text-decoration: none;
box-shadow: inset 1px 1px 3px rgba(0, 0, 0, 0.05);
transition: background 0.1s , color 0.1s;
}
.error_page_btn:hover, .error_page_btn:focus{
background: #4a708e;
color: #fff;
text-decoration: none;
}
.error_div{
padding: 15px;
max-width: 800px;
color: #383838;
box-shadow: none;
border: 1px solid rgba(217, 217, 217, 0.36);
}
</style>

<?php
}
?>
<!--=================================================footer==========================================================-->
<?php
}
?>
<script src="<?php echo $dircheckPath; ?>js/design.js"></script>
    <?php include "../includes/endJScodes.php"; ?>

    </body>
</html>