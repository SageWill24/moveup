<?php
error_reporting(E_ALL ^ E_NOTICE);
session_start();
if(isset($_SESSION['Username'])){
    header("location: home");
}
$getLang = trim(filter_var(htmlentities($_GET['lang']),FILTER_SANITIZE_STRING));
if (!empty($getLang)) {
$_SESSION['language'] = $getLang;
}
// ========================= config the languages ================================
error_reporting(E_NOTICE ^ E_ALL);
if (is_file('home.php')){
    $path = "";
}elseif (is_file('../home.php')){
    $path =  "../";
}elseif (is_file('../../home.php')){
    $path =  "../../";
}
include_once $path."langs/set_lang.php";
?>
<html dir="<? echo lang('html_dir'); ?>">
<head>
    <title><? echo lang('welcome'); ?> |Trappisone </title>
    <meta charset="UTF-8">
    <meta name="description" content="Trappisone ">
    <meta name="keywords" content="">
    <meta name="author" content="Sage-will">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
       <link rel="stylesheet" href="css/style.default.css" id="theme-stylesheet">
 <link rel="stylesheet" href="dist/css/w3.css"> 
    <link rel="stylesheet" href="css/custom.css">
      <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.min.css">
    <link rel="shortcut icon" href="img/favicon.png?3">
    <?php include "includes/head_imports_main.php";?>
    <style type="text/css">
body{
    background:#fff;
    
}
</style>
</head>
    <body class="login_signup_body">
        <div class="login_signup_navbar">
                <a href="index" class="text-base text-primary text-uppercase mb-4"><b>Trappisone</b></a>
                </div>
                <div class="w3-container w3-blue">
  <p class="w3-text-blue"><small> <center>Yadah Yadah Yadah </center></small></p></div>
<div class="w3-row-padding w3-center w3-margin-top">
<div class="w3-third">
  <div class="w3-card w3-container" style="min-height:260px">
  <h6 class="w3-text-blue"><b>#NICE</b></h6>
 <img src="imgs/guy.png" class="w3-circle w3-margin-right" style="width:46px">
  <p><small>Simple Landing page </small></p>
  
  </div>
</div>

<div class="w3-third">
  <div class="w3-card w3-container" style="min-height:260px">
  <h5 class="w3-text-blue"><b>#Inspiration</b></h5>
  <img src="imgs/hung.png" class="w3-circle w3-margin-right" style="width:46px">
  <p><small>Knocks You</small></p>

  </div>
</div>

<div class="w3-third">
  <div class="w3-card w3-container" style="min-height:260px">
  <h5 class="w3-text-blue"><b>#Experience</b></h5>
  <img src="imgs/vacancy.png" class="w3-circle w3-margin-right" style="width:46px">
  <p><small> comfortable with this stage of your life? </small></p>
  
  </div>
</div>
</div>
<br><br><br>
<nav class="navbar fixed-bottom navbar-light bg-light">
    <a href="login" class="w3-button w3-small w3-round w3-white w3-border w3-border-blue" type="button">Login </a>
  <a href="signup" class="w3-button w3-small w3-round w3-white w3-border w3-border-blue" type="button">Sign up</button>
</nav>
<script type="text/javascript">
function loginUser(){
var username = document.getElementById("un").value;
var password = document.getElementById("pd").value;
$.ajax({
type:'POST',
url:'includes/login_signup_codes.php',
data:{'req':'login_code','un':username,'pd':password},
beforeSend:function(){
$('.login_signup_btn1').hide();
$('#login_wait').html("<? echo lang('loading'); ?>...");
},
success:function(data){
$('#login_wait').html(data);
if (data == "Welcome...") {
    $('#login_wait').html("<p class='alertGreen'><? echo lang('welcome'); ?>..</p>");
    setTimeout(' window.location.href = "home"; ',2000);
}else{
    $('.login_signup_btn1').show();
}
},
error:function(err){
alert(err);
}
});
}
$('#loginFunCode').click(function(){
loginUser();
});
$(".login_signup_textfield").keypress( function (e) {
    if (e.keyCode == 13) {
        loginUser();
    }
});
</script>
</body>
</html>
