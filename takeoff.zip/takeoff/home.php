<?php
error_reporting(E_ALL ^ E_NOTICE);
session_start();
include("config/connect.php");
include("includes/fetch_users_info.php");
include ("includes/time_function.php");
include ("includes/num_k_m_count.php");
if(strlen($_SESSION['Username'])==0){

    header("location: index");
}
if (is_dir("imgs/")) {
        $check_path = "";
    }elseif (is_dir("../imgs/")) {
        $check_path = "../";
    }elseif (is_dir("../../imgs/")) {
        $check_path = "../../";
    }
?>

<?php
$s_id = $_SESSION['id'];
$s_fullname = $_SESSION['Fullname'];
$s_username = $_SESSION['Username'];
$s_userphoto = $_SESSION['Userphoto'];

$un = filter_var(htmlspecialchars($_GET['u']),FILTER_SANITIZE_STRING);
$uisql = "SELECT * FROM signup WHERE Username=:un";
$que = $conn->prepare($uisql);
$que->bindParam(':un', $un, PDO::PARAM_STR);
$que->execute();
while($row = $que->fetch(PDO::FETCH_ASSOC)){
    $row_id = $row['id'];
    $row_fullname = $row['Fullname'];
    $row_username = $row['Username'];
    $row_email = $row['Email'];
    $row_password = $row['Password'];
    $row_user_photo = $row['Userphoto'];
    $row_user_cover_photo = $row['user_cover_photo'];
 
    $row_verify = $row['verify'];
 
    $row_admin = $row['admin'];
    $row_gender = $row['gender'];
    $row_profile_pic_border = $row['profile_pic_border'];
    $row_language = $row['language'];
    $row_online = $row['online'];
}
?>
<html dir="<?php echo lang('html_dir'); ?>">
<head>
    <title>Home | Trappisone</title>
  
    
    <meta charset="UTF-8">
 <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="format-detection" content="telephone=no">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
         <!-- SCREEN VIEW  -->
        
<link rel="stylesheet" href="dist/css/w3.css">         
<link rel="stylesheet" href="css/sweepcss.css">
<link href="dist/css/swipe.min.css" type="text/css" rel="stylesheet">
<link href="css/design.css" rel="stylesheet">
 <?php include "includes/head_imports_main.php"; ?>
</head>
<style type="text/css">
body{
    background:#eceef3;
    
}
</style>
<body onload="fetchPosts_DB('home');">
 <nav class="w3-sidebar w3-collapse w3-white w3-animate-left" style="z-index:3;width:300px;" id="mySidebar"><br>
  <?php
       if (is_file("home.php")) {
                  $homePath = "home";
                }elseif (is_file("../home.php")) {
                    $homePath = "../home";
                }elseif (is_file("../../home.php")) {
                    $homePath = "../../home";
                }
                ?>
<div class="w3-container w3-card w3-light-grey w3-round w3-row">
    <div class="w3-col s8">
     <br>
                      <ul class="list-menu" style="margin-top: 8px;text-align: <?php echo lang('textAlign');?>">
                  
                       <a href="<?php echo $dircheckPath; ?>u/<?php echo $_SESSION['Username']; ?>">
                            
                                           <div>
                                               <img class="w3-circle" style="height:30px;width:30px" src="<?php echo $dircheckPath.'imgs/user_imgs/'.$_SESSION['Userphoto']; ?>"><br>
                                                <?php echo $_SESSION['Fullname']."<br><span style='color: #848484; font-size: 13px;'>@".$_SESSION['Username']."</span>"; ?>
                                           </div>
                                     
                            </a>
    </div>
 
  </div>
    <div class="w3-col s8 w3-bar w3-hide-large">
      <span class="w3-text-pink"><strong> Trappisone</strong></span>
         </div>
  <div class="w3-col s8 w3-bar w3-hide-small">
      <span class="w3-text-pink"><strong> Trappisone</strong></span><br>
      <a href="<?php echo $dircheckPath; ?>post" class="w3-bar-item w3-button w3-text-blue"><i class="fa fa-pencil"></i></a>
      <a href="" class="w3-bar-item w3-button w3-text-blue"><i class="fa fa-users"></i></a>
      <a href="" class="w3-bar-item w3-button w3-text-blue"><i class="fa fa-cog"></i></a>
    </div>
  </div>
  <div class="w3-bar-block">
    <a href="#" class="w3-bar-item w3-button w3-padding-16 w3-hide-large w3-light-grey w3-hover-white" onclick="w3_close()" title="close menu"><i class="fa fa-close fa-fw"></i>Close</a>
    <a href="#" class="w3-bar-item w3-button w3-padding w3-light-grey">Account Overview</a>
    <a href="#" class="w3-bar-item w3-button w3-padding w3-text-blue"><i class="fa fa-user fa-fw"></i>  Profile</a>
    <a href="<?php echo $dircheckPath; ?>logout" class="w3-bar-item w3-button w3-padding w3-text-pink"><i class="fa fa-sign-out fa-fw"></i><?php echo lang('logout'); ?></a>
    <a href="" class="w3-bar-item w3-button w3-padding w3-text-pink"><i class="fa fa-cog fa-fw"></i>  Settings</a><br><br>
  </div>
</nav>
<!-- Overlay effect when opening sidebar on small screens -->
<div class="w3-overlay w3-hide-large w3-animate-opacity" onclick="w3_close()" style="cursor:pointer" title="close side menu" id="myOverlay"></div>
<header class="w3-top w3-bar w3-white">
  <button class="w3-bar-item w3-button w3-text-pink w3-xlarge w3-hover-theme" onclick="openSidebar()">&#9776;</button>
<p class="w3-text-pink w3-bar-item"><b>Trappisone</b></p>
<a href=""><i class="material-icons w3-hide-small w3-text-blue">group</i></a>
 <a href=""><i class="material-icons w3-hide-small w3-text-blue ">create</i></a>
<a href="javascript:void(0);"class="w3-right w3-text-pink w3-padding-4 w3-icon" style="padding: 10px 5px;" id="nav_Noti_Btn"><i class="material-icons ">notifications_none</i> <?php echo lang('Notifications'); ?><small> <span id="notificationsCount"></span></small></a>
</header>
                <div class="w3-container">
                <div class=" w3-card w3-white navbar_fetchBox " id="notifications_box">
                <div style="position:relative;"><small><?php echo lang('notifications'); ?></small>
                    <span class="toTopArrow" span class='toTopArrow' style="position: absolute; top: -10px;<?php echo lang('float'); ?>:30px;"></span>
                </div>
                <div id="notifications_rP" class="scrollbar" style=" overflow-y: scroll;">
                    <div id="notifications_r" data-load="0">
                        <div id="notifications_data"></div>
                        <p style='width: 20%;border:none;display: none' id="notifications_loading" align='center'><img src='<?php echo $dircheckPath; ?>imgs/loading_video.gif' style='width:20px;box-shadow: none;height: 20px;'></p>
                        <p id="notifications_noMore" style='display:none;color:#9a9a9a;font-size:14px;text-align:center;'><?php echo lang('no_notifications'); ?></p>
                        <input type="hidden" id="notifications_load" value="0"> 
                    </div>
                </div>
                <div id='sqresultItem' align='center' style='background: #efefef; border: 1px solid #e0e0e0;'>
                <a href='<?php echo $dircheckPath; ?>notifications'>
               <div style='display: inline-flex;width: 100%;'>
                <p style='font-size:13px;'><?php echo lang('see_all'); ?>
                </p>
                </div>
                </a>
                </div>
                </div>
                <div id="nav_newNotify" data-show='0'></div>
</div>
<div style="" id='nSound'></div>

<!--=============================[ IGNORE FOR NOW ]========================================-->


        <div class="w3-main" style="margin-left:300px;margin-top:43px;">


 <div class="write_post">
                <?php echo $err_success_Msg; ?>
             
                </div>
                <div class="w3-row">
                      <div class="w3-col m5">
                   <div id="FetchingPostsDiv">
                </div>
                <div class="post loading-info" id="LoadingPostsDiv" style="padding: 8px;padding-bottom: 100px;">
                    <div class="animated-background">
                        <div class="background-masker header-top"></div>
                        <div class="background-masker header-left"></div>
                        <div class="background-masker header-right"></div>
                        <div class="background-masker header-bottom"></div>
                        <div class="background-masker subheader-left"></div>
                        <div class="background-masker subheader-right"></div>
                        <div class="background-masker subheader-bottom"></div>
                        <div class="background-masker content-top"></div>
                        <div class="background-masker content-first-end"></div>
                        <div class="background-masker content-second-line"></div>
                        <div class="background-masker content-second-end"></div>
                        <div class="background-masker content-third-line"></div>
                        <div class="background-masker content-third-end"></div>
                    </div>
                </div>
                <div class="post  loading-info" id="NoMorePostsDiv" style="display: none;">
                  <p style="color: #b1b1b1;text-align: center;padding: 15px;margin: 0px;font-size: 18px;"><?php echo lang('noMoreStories'); ?></p>
                </div>
                <div class="post  loading-info" id="LoadMorePostsBtn" style="display: none;">
                  <button class="blue_flat_btn" style="width: 100%" onclick="fetchPosts_DB('home')"><?php echo lang('load_more'); ?></button>
                </div>
                <input type="hidden" id="GetLimitOfPosts" value="0">
     
</div></div></div>
<!--=============================[ NavBar dowwwwwwwwnnnnnnn ]========================================-->
<?php include "includes/bottomnav.php"; ?>

<script type="text/javascript">
$('.postContent_EditBox').each(function () {
  this.setAttribute('style', 'height:' + (this.scrollHeight) + 'px;overflow-y:hidden;text-align:' + "<?php echo lang('post_textbox_align'); ?>;");
}).on('input', function () {
  this.style.height = 'auto';
  this.style.height = (this.scrollHeight) + 'px';
});
$("#trPagesTab").click(function(){
$("#trPagesTab").css({"background": "#fff"});
$("#trPostsTab").css({"background": "#e9ebee"});
$("#trPages").show();
$("#trPosts").hide();
});
$("#trPostsTab").click(function(){
$("#trPostsTab").css({"background": "#fff"});
$("#trPagesTab").css({"background": "#e9ebee"});
$("#trPosts").show();
$("#trPages").hide();
});
</script>

<script type="text/javascript">
  function myFunction(id) {
  var x = document.getElementById(id);
  if (x.className.indexOf("w3-show") == -1) {
    x.className += " w3-show";
  } else { 
    x.className = x.className.replace(" w3-show", "");
  }
}  
</script>
<?php include "includes/endJScodes.php"; ?>
<?php include ($dircheckPath."js/navbar_nottifi_js.php"); ?>
<script>
closeSidebar();
function openSidebar() {
  document.getElementById("mySidebar").style.display = "block";
}

// Close the sidebar with the close button
function w3_close() {
  mySidebar.style.display = "none";
  overlayBg.style.display = "none";
}

</script>

<script src="js/design.js"></script>

  <script src="js/bootstrap.bundle.min.js"></script>

</body>
</html>
